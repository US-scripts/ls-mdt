var  debugdata = {
    currentuser: {
        identifier: "QAJDIOASD",
        job: {
            name: "police",
        },
        department: "LSPD",
        charinfo: {
            firstname: "Zort",
            lastname: "Port"
        },
    },
    employees: {

        "QA8125DD21": {
            name: "David Cold",
            onduty: true,
            department: "LSPD",
            callsign: "A-44",
            radio: 12.4,
            history: {
                responded_week: 1,
            }
        },
        "QAJDIOASD": {
            name: "David Cold",
            onduty: true,
            department: "LSPD",
            callsign: "A-44",
            radio: 12.4,
            history: {
                responded_week: 1,
            }
        },
    },
    bulletin_board: {
        "tyjzgqnrLOrpNGsmXA9SW5": {
            identifier: "tyjzgqnrLOrpNGsmXA9SW5",
            header: "Always Protect Yourself!",
            desc: "First of all, your own safety. Before without being involved protect yourself!",
            time: "1673336500",
            caseNumber: 1,
        },
    },
    dispatchs: {
        [1]: {
                "job":["police","ambulance"],
                "dispatchMessage":"Incoming Anonymous Call",
                "name":"Anonymous",
                "origin":{
                    "z":35.17932510375976,
                    "y":-1096.6959228515625,
                    "x":-57.68916320800781
                },
                "source":1,
                "number":"Hidden Number",
                "units":[],
                "information":"test",
                "dispatchCode":"911",
                "priority":2,
                "callId":1,
                "responses":[],
                "firstStreet":"Power St, Pillbox Hill",
                "dispatchcodename":"911call",
                "time":1674052619000
            },
            [2]: {
                "job":["police","ambulance"],
                "dispatchMessage":"Incoming Anonymous Call",
                "name":"Anonymous",
                "origin":{
                    "z":35.571533203125,
                    "y":-1096.7154541015625,
                    "x":-40.12158203125
                },
                "source":1,
                "number":"Hidden Number",
                "units":{
                    ["1"]: {
                        identifier: "QAJDIOASD",
                        fullname: "David Cold",
                        job: "Police",
                        callsign: "A-44"
                    }
                },
                "information":"test",
                "dispatchCode":"911",
                "priority":2,
                "callId":2,
                "responses":[],
                "firstStreet":"Power St, Pillbox Hill",
                "dispatchcodename":"911call",
                "time":1674054495000
            },
 },
    users: {
        "QA8125DD21": {
            identifier: "QA8125DD21",
            charinfo: {
                firstname: "Abraham",
                lastname: "Lincoln",
                dob: "12/12/1999"
            },
            job: {
                name: "police",
                label: "Police",
                grade: "Sergant II",
            },

            properties: ["Inteii"],
            gallery: { "ASFJASHUI": "https://s.abcnews.com/images/US/george-floyd-ap-jt-200529_hpMain_2_4x3t_608.jpg" },
            profileimage: "https://discord.gg/0resmon",
            tags: [ "Wanted", "Idiot" ],
            vehicles: ["5MD31 - Taurus"],
            licenses: ["weapon"],
        },
        "QAJDIOASD": {
            identifier: "QAJDIOASD",
            charinfo: {
                firstname: "Abraham",
                lastname: "Lincoln",
                dob: "12/12/1999"
            },
            job: {
                name: "police",
                label: "Police",
                grade: "Sergant II",
            },

            properties: ["Inteii"],
            gallery: { "ASFJASHUI": "https://s.abcnews.com/images/US/george-floyd-ap-jt-200529_hpMain_2_4x3t_608.jpg" },
            profileimage: "https://discord.gg/0resmon",
            tags: [ "Wanted", "Idiot" ],
            vehicles: ["5MD31 - Taurus"],
            licenses: ["weapon"],
        },
        "DCE87213":{"profileimage":"https://t3.ftcdn.net/jpg/03/39/45/96/360_F_339459697_XAFacNQmwnvJRqe1Fe9VOptPWMUxlZP8.jpg","identifier":"DCE87213","vehicles":[],"licenses":[],"job":{"name":"unemployed","grade":"Freelancer","label":"Civilian"},"tags":[],"properties":[],"gallery":[],"charinfo":{"firstname":"Jamison","lastname":"Rowland","dob":"1994-08-21"}},"YHP97012":{"profileimage":"https://t3.ftcdn.net/jpg/03/39/45/96/360_F_339459697_XAFacNQmwnvJRqe1Fe9VOptPWMUxlZP8.jpg","identifier":"YHP97012","vehicles":["6AS941ZU - comet2","5WF367JF - comet2"],"licenses":[],"tags":{"0":"Input Tags..."},"user":{"Functions":{"Logout":{"__cfx_functionSource":false,"__cfx_functionReference":"ls-core:20037:1610"},"SetJobDuty":{"__cfx_functionSource":false,"__cfx_functionReference":"ls-core:20037:1613"},"AddJobReputation":{"__cfx_functionSource":false,"__cfx_functionReference":"ls-core:20037:1607"},"ClearInventory":{"__cfx_functionSource":false,"__cfx_functionReference":"ls-core:20037:1600"},"RemoveMoney":{"__cfx_functionSource":false,"__cfx_functionReference":"ls-core:20037:1601"},"SetMoney":{"__cfx_functionSource":false,"__cfx_functionReference":"ls-core:20037:1602"},"SetMetaData":{"__cfx_functionSource":false,"__cfx_functionReference":"ls-core:20037:1599"},"GetCardSlot":{"__cfx_functionSource":false,"__cfx_functionReference":"ls-core:20037:1605"},"AddMoney":{"__cfx_functionSource":false,"__cfx_functionReference":"ls-core:20037:1615"},"AddItem":{"__cfx_functionSource":false,"__cfx_functionReference":"ls-core:20037:1616"},"Save":{"__cfx_functionSource":false,"__cfx_functionReference":"ls-core:20037:1608"},"GetMoney":{"__cfx_functionSource":false,"__cfx_functionReference":"ls-core:20037:1617"},"GetItemBySlot":{"__cfx_functionSource":false,"__cfx_functionReference":"ls-core:20037:1598"},"SetInventory":{"__cfx_functionSource":false,"__cfx_functionReference":"ls-core:20037:1604"},"UpdatePlayerData":{"__cfx_functionSource":false,"__cfx_functionReference":"ls-core:20037:1606"},"SetCreditCard":{"__cfx_functionSource":false,"__cfx_functionReference":"ls-core:20037:1597"},"GetItemByName":{"__cfx_functionSource":false,"__cfx_functionReference":"ls-core:20037:1603"},"SetJob":{"__cfx_functionSource":false,"__cfx_functionReference":"ls-core:20037:1614"},"RemoveItem":{"__cfx_functionSource":false,"__cfx_functionReference":"ls-core:20037:1612"},"GetItemsByName":{"__cfx_functionSource":false,"__cfx_functionReference":"ls-core:20037:1611"},"SetGang":{"__cfx_functionSource":false,"__cfx_functionReference":"ls-core:20037:1609"}},"PlayerData":{"name":"LquenS","optin":true,"source":1,"cid":1,"citizenid":"YHP97012","license":"license:d4815f16310f3c6774ae0e3c3f7cc247cc7f96e7","id":3114,"gang":{"label":"No Gang Affiliaton","grade":{"name":"none","level":0},"isboss":false,"name":"none"},"charinfo":{"backstory":"placeholder backstory","birthdate":"1998-02-19","nationality":"American","lastname":"Ortiz","firstname":"Nicholas","gender":0,"cid":"1","phone":3747727153,"account":"US07QBCore1625300122"},"items":[],"last_updated":[],"inventory":"[]","job":{"grade":{"name":"Chief","level":4},"onduty":true,"name":"police","label":"Law Enforcement","payment":150,"type":"leo","isboss":true},"position":{"x":78.72528076171875,"z":20.75390625,"y":-1929.91650390625},"metadata":{"jobrep":{"taxi":0,"trucker":0,"hotdog":0,"tow":0},"criminalrecord":{"hasRecord":false},"stress":0,"bloodtype":"B-","ishandcuffed":false,"status":[],"commandbinds":[],"isdead":false,"callsign":"NO CALLSIGN","inlaststand":false,"attachmentcraftingrep":0,"licences":{"driver":true,"weapon":false,"business":false},"tracker":false,"thirst":100,"jailitems":[],"phonedata":{"SerialNumber":90943873,"InstalledApps":[]},"walletid":"QB-76179948","injail":0,"dealerrep":0,"fitbit":[],"phone":[],"armor":0,"fingerprint":"zo605M86eMg1134","craftingrep":0,"hunger":100,"inside":{"apartment":[]}},"money":{"bank":285163,"crypto":0,"cash":1845616}},"Offline":false},"job":{"name":"police","grade":"Chief","label":"Law Enforcement"},"properties":[],"gallery":[],"charinfo":{"firstname":"Nicholas","lastname":"Ortiz","dob":"1998-02-19"}},"FCO60047":{"profileimage":"https://t3.ftcdn.net/jpg/03/39/45/96/360_F_339459697_XAFacNQmwnvJRqe1Fe9VOptPWMUxlZP8.jpg","identifier":"FCO60047","vehicles":[],"licenses":[],"job":{"name":"police","grade":"Recruit","label":"Law Enforcement"},"tags":{"0":"Wanted"},"properties":[],"gallery":[],"charinfo":{"firstname":"Lily","lastname":"Small","dob":"1998-12-05"}},"RKN74802":{"profileimage":"https://t3.ftcdn.net/jpg/03/39/45/96/360_F_339459697_XAFacNQmwnvJRqe1Fe9VOptPWMUxlZP8.jpg","identifier":"RKN74802","vehicles":[],"licenses":[],"job":{"name":"unemployed","grade":"Freelancer","label":"Civilian"},"tags":{"0":"Wanted"},"properties":[],"gallery":{"0":"https://media.discordapp.net/attachments/978047232211292210/1063921333894918295/image.png"},"charinfo":{"firstname":"ADASd","lastname":"ASDSAD","dob":"1112-12-04"}},"ZNP35182":{"profileimage":"https://t3.ftcdn.net/jpg/03/39/45/96/360_F_339459697_XAFacNQmwnvJRqe1Fe9VOptPWMUxlZP8.jpg","identifier":"ZNP35182","vehicles":[],"licenses":{"0":"weapon","1":"driver"},"job":{"name":"unemployed","grade":"Freelancer","label":"Civilian"},"tags":[],"properties":[],"gallery":[],"charinfo":{"firstname":"asd","lastname":"dsad","dob":"1997-11-11"}}

    },
    incidents: {
        "tyjzgqnrLOrpNGsmXA9SW5":{
            "identifier":"tyjzgqnrLOrpNGsmXA9SW5",
            "title":"asdasd",
            "time":"asdasd",
            "location":"asdasdasd",
            "commitList":{},
            "crimeList":{
                [1]: "Abraham Lincoln",
            },
            "officerList":{},
            "hostageList":{},
            "witnessList":{},
            "weponList":{},
            "galleryList":{},
            "fineAmount":"0$",
            "sentenceAmount":"0",
            "caseNumber":1,
            "creatorIncident":"David Lincoln",
            "description":"Title: \nStore Robbing \nLocation: \nCriminal Weapons:\nHostage:\nCriminal Involved:\n\nCrimes Commited:\nPenalty Amount:\nDetention Period:\nWitness:\nEvidence:\n\nOfficers Involved:"
        }
    },
    reports: {},
    bolo: {},
    penal: {
            [1]: {
                title: "Offenses to Persons",
                values: {
                    [1]: {
                        ['months']: 15,
                        ['color']: 'mid',
                        ['title']: 'Assault',
                        ['fine']: 850
                    },
                    [2]: {
                        ['months']: 30,
                        ['color']: 'high',
                        ['title']: 'Assault Deadly Weapon',
                        ['fine']: 3750
                    },
                    [3]: {
                        ['months']: 50,
                        ['color']: 'high',
                        ['title']: 'Attempted Murder Civilian',
                        ['fine']: 7500
                    },
                    [4]: {
                        ['months']: 50,
                        ['color']: 'high',
                        ['title']: 'Accessory to Second Degree Murder',
                        ['fine']: 5000
                    },
                    [5]: {
                        ['months']: 0,
                        ['color']: 'high',
                        ['title']: 'First Degree Murder',
                        ['fine']: 0
                    },
                    [6]: {
                        ['months']: 5,
                        ['color']: 'mid',
                        ['title']: 'Criminal Threats',
                        ['fine']: 500
                    },
                    [7]: {
                        ['months']: 20,
                        ['color']: 'mid',
                        ['title']: 'Hostage Taking',
                        ['fine']: 1200
                    },
                    [8]: {
                        ['months']: 0,
                        ['color']: 'high',
                        ['title']: 'Accessory to the murder public employee',
                        ['fine']: 0
                    },
                    [9]: {
                        ['months']: 15,
                        ['color']: 'mid',
                        ['title']: 'Kidnapping',
                        ['fine']: 900
                    }
                }
            },
            [2]: {
                title: "Offenses to Fraud",
                values: {
                    [1]: {
                        ['months']: 25,
                        ['color']: 'low',
                        ['title']: 'Robbery',
                        ['fine']: 2000
                    },
                    [2]: {
                        ['months']: 10,
                        ['color']: 'low',
                        ['title']: 'Grand Theft',
                        ['fine']: 600
                    },
                    [3]: {
                        ['months']: 15,
                        ['color']: 'mid',
                        ['title']: 'Sale of items used in crime',
                        ['fine']: 1000
                    },
                    [4]: {
                        ['months']: 30,
                        ['color']: 'mid',
                        ['title']: 'Carjacking',
                        ['fine']: 2000
                    },
                    [5]: {
                        ['months']: 10,
                        ['color']: 'low',
                        ['title']: 'Burglary',
                        ['fine']: 500
                    },
                    [6]: {
                        ['months']: 20,
                        ['color']: 'low',
                        ['title']: 'Theft of an Aircraft',
                        ['fine']: 1000
                    }
                }
            },
            [3]: {
                title: "Offenses to Fraud",
                values: {
                    [1]: {
                        ['months']: 10,
                        ['color']: 'low',
                        ['title']: 'Possession of Stolen Identification',
                        ['fine']: 750
                    },
                    [2]: {
                        ['months']: 15,
                        ['color']: 'low',
                        ['title']: 'Impersonating',
                        ['fine']: 1250
                    },
                    [3]: {
                        ['months']: 15,
                        ['color']: 'low',
                        ['title']: 'Forgery',
                        ['fine']: 750
                    }
                }
            },
            [4]: {
                title: "Offenses to Damage Property",
                values: {
                    [1]: {
                        ['months']: 10,
                        ['color']: 'low',
                        ['title']: 'Trespassing',
                        ['fine']: 450
                    },
                    [2]: {
                        ['months']: 0,
                        ['color']: 'low',
                        ['title']: 'Vandalism',
                        ['fine']: 300
                    }
                }
            },
            [5]: {
                title: "Offenses to Law",
                values: {
                    [1]: {
                        ['months']: 25,
                        ['color']: 'mid',
                        ['title']: 'Accessory to Jailbreak',
                        ['fine']: 2000
                    },
                    [2]: {
                        ['months']: 20,
                        ['color']: 'mid',
                        ['title']: 'Attempted Jailbreak',
                        ['fine']: 1500
                    },
                    [3]: {
                        ['months']: 0,
                        ['color']: 'low',
                        ['title']: 'Perjury',
                        ['fine']: 0
                    },
                    [4]: {
                        ['months']: 20,
                        ['color']: 'low',
                        ['title']: 'Violation of a Restraining Order',
                        ['fine']: 2250
                    },
                    [5]: {
                        ['months']: 5,
                        ['color']: 'mid',
                        ['title']: 'Resisting Arrest',
                        ['fine']: 300
                    },
                    [6]: {
                        ['months']: 30,
                        ['color']: 'mid',
                        ['title']: 'Jailbreak',
                        ['fine']: 2500
                    }
                }
            },
            [6]: {
                title: "Offenses to Order",
                values: {
                    [1]: {
                        ['months']: 0,
                        ['color']: 'low',
                        ['title']: 'Disobeying a Officer',
                        ['fine']: 750
                    },
                    [2]: {
                        ['months']: 10,
                        ['color']: 'low',
                        ['title']: 'False Reporting',
                        ['fine']: 750
                    },
                    [3]: {
                        ['months']: 10,
                        ['color']: 'mid',
                        ['title']: 'Harassment',
                        ['fine']: 500
                    },
                    [4]: {
                        ['months']: 10,
                        ['color']: 'low',
                        ['title']: 'Misdemeanor Obstruction of Justice',
                        ['fine']: 500
                    },
                    [5]: {
                        ['months']: 10,
                        ['color']: 'low',
                        ['title']: 'Tampering',
                        ['fine']: 500
                    },
                    [6]: {
                        ['months']: 10,
                        ['color']: 'low',
                        ['title']: 'Harboring a Fugitive',
                        ['fine']: 1000
                    },
                    [7]: {
                        ['months']: 15,
                        ['color']: 'mid',
                        ['title']: 'Aiding and Abetting',
                        ['fine']: 450
                    },
                    [8]: {
                        ['months']: 15,
                        ['color']: 'low',
                        ['title']: 'Failure to Provide Identification',
                        ['fine']: 1500
                    },
                    [9]: {
                        ['months']: 10,
                        ['color']: 'mid',
                        ['title']: 'Unlawful Assembly',
                        ['fine']: 750
                    }
                }
            },
            [7]: {
                title: "Offenses to Health",
                values: {
                    [1]: {
                        ['months']: 30,
                        ['color']: 'mid',
                        ['title']: 'Cultivation of Drug',
                        ['fine']: 1500
                    },
                    [2]: {
                        ['months']: 5,
                        ['color']: 'low',
                        ['title']: 'Misdemeanor Possession Drug',
                        ['fine']: 250
                    },
                    [3]: {
                        ['months']: 15,
                        ['color']: 'low',
                        ['title']: 'Felony Possession of Drug',
                        ['fine']: 1000
                    },
                    [4]: {
                        ['months']: 0,
                        ['color']: 'high',
                        ['title']: 'Drug Trafficking',
                        ['fine']: 0
                    }
                }
            },
            [8]: {
                title: "Offenses to Vehicle",
                values: {
                    [1]: {
                        ['months']: 0,
                        ['color']: 'low',
                        ['title']: 'Illegal Turn',
                        ['fine']: 150
                    },
                    [2]: {
                        ['months']: 5,
                        ['color']: 'low',
                        ['title']: 'Driving While High',
                        ['fine']: 300
                    },
                    [3]: {
                        ['months']: 5,
                        ['color']: 'low',
                        ['title']: 'Evading',
                        ['fine']: 400
                    },
                    [4]: {
                        ['months']: 10,
                        ['color']: 'mid',
                        ['title']: 'Reckless Evading',
                        ['fine']: 800
                    },
                    [5]: {
                        ['months']: 0,
                        ['color']: 'low',
                        ['title']: 'Driving without Headlights/Signals',
                        ['fine']: 300
                    },
                    [6]: {
                        ['months']: 15,
                        ['color']: 'low',
                        ['title']: 'Street Racing',
                        ['fine']: 1500
                    },
                    [7]: {
                        ['months']: 0,
                        ['color']: 'low',
                        ['title']: 'Nonfunctional Vehicle',
                        ['fine']: 75
                    },
                    [8]: {
                        ['months']: 0,
                        ['color']: 'low',
                        ['title']: 'Negligent Driving',
                        ['fine']: 300
                    },
                    [9]: {
                        ['months']: 10,
                        ['color']: 'mid',
                        ['title']: 'Reckless Driving',
                        ['fine']: 750
                    },
                    [10]: {
                        ['months']: 0,
                        ['color']: 'low',
                        ['title']: 'Speeding',
                        ['fine']: 750
                    },
                    [11]: {
                        ['months']: 0,
                        ['color']: 'low',
                        ['title']: 'Illegal Passing',
                        ['fine']: 300
                    },
                    [12]: {
                        ['months']: 10,
                        ['color']: 'low',
                        ['title']: 'Hit and Run',
                        ['fine']: 500
                    },
                    [13]: {
                        ['months']: 0,
                        ['color']: 'low',
                        ['title']: 'Failure to Stop',
                        ['fine']: 600
                    }
                }
            },
            [9]: {
                title: "Offenses to Wildlife",
                values: {
                    [1]: {
                        ['months']: 0,
                        ['color']: 'low',
                        ['title']: 'Hunting in Restricted Areas',
                        ['fine']: 450
                    },
                    [2]: {
                        ['months']: 0,
                        ['color']: 'low',
                        ['title']: 'Unlicensed Hunting',
                        ['fine']: 450
                    }
                }
            }
    }
}

OpenMDT()
SetupMDT(debugdata)

document.addEventListener('contextmenu', event => event.preventDefault());